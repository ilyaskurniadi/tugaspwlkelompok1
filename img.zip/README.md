# Sistem-Persediaan-Obat-Apotik-Sutomo-Tanjung-Balai
Sistem ini merupakan sebuah sistem informasi mengenai persediaan obat pada apotik sutomo Tanjung Balai. Pada sistem ini , terdapat 2 user yaitu admin dan pemilik toko. Dimana setiap user memiliki fungsi yang berbeda. Pada admin bisa mengelola persediaan obat yang didalamnya terdapat obat masuk dan obat keluar. Pada pemilik , hanya bisa melihat laporan saja

Tampilan Sistem :

![s1](https://user-images.githubusercontent.com/98314457/150763967-1ce1c9ac-d032-48a1-800e-3503a62d0d55.png)
![s2](https://user-images.githubusercontent.com/98314457/150763978-190fbb7c-0b22-4676-adbe-055e503f8b1e.png)
![s3](https://user-images.githubusercontent.com/98314457/150763987-93f4e9c0-6cef-4a13-9c20-54eedef77ba6.png)
![s4](https://user-images.githubusercontent.com/98314457/150763993-c8ecda02-5426-44f7-9a49-ba8666c40d88.png)
![s5](https://user-images.githubusercontent.com/98314457/150763995-b6d7907c-64a3-4e8c-a005-2d70a96ade8a.png)
