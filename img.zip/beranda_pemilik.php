<div class="container">
    <div class="row">
        <div class ="col-xs-12">

            <div class="alert alert-info">
                Selamat datang kembali <strong><?=$_SESSION['nama']?></strong>
            </div>
        </div>
    </div>
    <div class="row">
        <!--colomn kedua-->
        <div class="col-sm-12 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">HALAMAN PEMILIK Sistem aplikasi pengendalian stok dan penjualan obat pada klinik medika insani </h3>
                </div>
                <div class="panel-body">
                     <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                       <thead>
                          <p align="center"><img src="img/images.PNG"></img></p>
                        
                        </thead>


                    </table>
                </div>
            </div>
        </div>
</div>

