<!DOCTYPE html>
<html>
    <head>
        <title>DATA PERSEDIAAN OBAT</title>
        <link href="../Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body onload="print()">
        <!--Menampilkan data detail arsip-->
        <?php
        include '../config/koneksi.php';
        $ambilthn=$_POST['tahun'];
        ?>   

        <div class="container">
            <div class='row'>
                <div class="col-sm-12">
                    <!--dalam tabel--->
                    <div class="text-center">
                        <img src="../img/images.PNG" height="50px">
                        <h2>Sistem Aplikasi Pengendalian Stok dan Penjualan Obat Pada Klinik Medika Insani </h2>
                        <h4>Ruko Perum Jatiwarna Indah, Jl. Pagelarang, RT.005/RW.009, Jatiwarna, Kec. Pd. Melati, Kota Bks, Jawa Barat 17415</h4>
                        <hr>
                        <h3>DATA PERSEDIAAN OBAT</h3>
                        <table class="table table-bordered table-striped table-hover"> 
                        <tbody>
                                <thead>
								<tr>
									<th>No.</th><th>Nama Obat</th><th width="14%"><center>Jenis Obat</center></th><th width="15%"><center>Stok</center></th><th width="10%">Tgl. Exp</th>
								</tr>
								</thead>
							<tbody>
                            <!--ambil data dari database, dan tampilkan kedalam tabel-->
                            <?php
                            //buat sql untuk tampilan data, gunakan kata kunci select
                            $sql = "SELECT * FROM tbl_persediaanobat WHERE substr(tgl_exp,1,4)='$ambilthn'";
                            $query = mysqli_query($koneksi, $sql) or die("SQL Anda Salah");
                            //Baca hasil query dari databse, gunakan perulangan untuk 
                            //Menampilkan data lebh dari satu. disini akan digunakan
                            //while dan fungdi mysqli_fecth_array
                            //Membuat variabel untuk menampilkan nomor urut
                            $nomor = 0;
                            //Melakukan perulangan u/menampilkan data
                            while ($data = mysqli_fetch_array($query)) {
                                $nomor++; //Penambahan satu untuk nilai var nomor
                                ?>
                                <tr>
                                    <td><?= $nomor ?></td>
                                    <td><?= $data['nama_obat'] ?></td>                                   
                                    <td><?= $data['jenis_obat'] ?></td>
                                    <td><?= $data['stok'] ?></td>
                                    <td><?= $data['tgl_exp'] ?></td>
                                    <td>
                                </tr>
                                <!--Tutup Perulangan data-->
                            <?php } ?>
							</tbody>
                        </tbody>
                            <tfoot> 
                                <tr>
                                    <td colspan="8" class="text-right">
                                        Bekasi  <?= date("d-m-Y") ?>
                                        <br><br><br><br>
                                        <u>Dr. Arif<strong></u><br>
                                        NIP.102871291416712
									</td>
								</tr>
							</tfoot> 
                        </table>
                    </div>
                </div>
            </div>
    </body>
</html>