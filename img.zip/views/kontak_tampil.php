<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> Kontak</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <label class="col-sm-12 control-label"><center><strong>KELOMPOK 1</strong></center></label>
                            <p align="center">
                              TUGAS BESAR PEMGORAMAN WEB LANJUTAN
                            </p>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            1.202042502505 Ilyas Kurniadi<br>
                            2.202043500964 Kristianto<br>
                            3.202043501010 Nadiyah Syahdatur Syamsi<br>
                            4.202043500999 Michelle Prihastyanita PPH<br>
                            5.202043500989 Mirrah Azizah<br>
                            6.202043501012 Ahmad Fauzi<br>
                            7.202043502507 Faqih Trivano<br>
                            8.202043501049 Abu Dzar Al-Ghifari<br>
                            <br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
